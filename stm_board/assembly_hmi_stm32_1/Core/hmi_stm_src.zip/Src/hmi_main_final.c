/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include "clcd.h"
#include "dht.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#ifdef __GNUC__
/* With GCC, small printf (option LD Linker->Libraries->Small printf
   set to 'Yes') calls __io_putchar() */
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */
#define ARR_CNT 5
#define CMD_SIZE 128
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

I2C_HandleTypeDef hi2c3;

UART_HandleTypeDef huart2;
UART_HandleTypeDef huart6;

/* USER CODE BEGIN PV */
volatile uint8_t estopEvent = 0;
volatile uint8_t estopLatched = 0;

uint8_t rx2char;
volatile unsigned char rx2Flag = 0;
volatile char rx2Data[50];
uint8_t btchar;
char btData[CMD_SIZE];

#define BT_RX_QUEUE_SIZE 8

char btRxQueue[BT_RX_QUEUE_SIZE][CMD_SIZE];

volatile uint8_t btRxHead = 0;
volatile uint8_t btRxTail = 0;
volatile uint32_t btRxDropCount = 0;
uint16_t ADC1ConvertValue[2] = {0,};
__IO int adcFlag = 0;
GPIO_PinState startRawPrev = GPIO_PIN_SET;
GPIO_PinState startStable = GPIO_PIN_SET;
uint32_t startChangeTick = 0;

GPIO_PinState checkRawPrev = GPIO_PIN_SET;
GPIO_PinState checkStable = GPIO_PIN_SET;
uint32_t checkChangeTick = 0;

GPIO_PinState endRawPrev = GPIO_PIN_SET;
GPIO_PinState endStable = GPIO_PIN_SET;
uint32_t endChangeTick = 0;

uint32_t endPressTick = 0;
uint8_t estopClearSent = 0;

#define ESTOP_CLEAR_HOLD_MS 2000U

GPIO_PinState modeRawPrev = GPIO_PIN_SET;
GPIO_PinState modeStable = GPIO_PIN_SET;
uint32_t modeChangeTick = 0;

uint8_t manualMode = 0;   // 0 = AUTO, 1 = MANUAL

uint16_t potValue = 0;
uint32_t potReadTick = 0;
uint16_t potAccepted = 0;
uint8_t potInitialized = 0;

#define POT_DEADBAND 50

uint16_t trayAngle = 90;

typedef enum
{
    HMI_READY = 0,
    HMI_WORKING,
    HMI_INSPECTING,
    HMI_PASS,
    HMI_FAIL,
    HMI_HOMING,
    HMI_ESTOP
} HMI_State;

HMI_State hmiState = HMI_READY;

uint32_t rgbBlinkTick = 0;
uint8_t rgbBlinkState = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART6_UART_Init(void);
static void MX_I2C3_Init(void);
static void MX_ADC1_Init(void);

/* USER CODE BEGIN PFP */
void bluetooth_Event();

void RGB_Set(uint8_t r, uint8_t g, uint8_t b);
void RGB_Update(void);
void HMI_ShowMode(void);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_USART6_UART_Init();
  MX_I2C3_Init();
  MX_ADC1_Init();
  /* USER CODE BEGIN 2 */



  HAL_UART_Receive_IT(&huart2, &rx2char,1);
  HAL_UART_Receive_IT(&huart6, &btchar,1);
  startRawPrev = HAL_GPIO_ReadPin(START_BTN_GPIO_Port, START_BTN_Pin);
  startStable = startRawPrev;
  startChangeTick = HAL_GetTick();

  checkRawPrev = HAL_GPIO_ReadPin(CHECK_BTN_GPIO_Port, CHECK_BTN_Pin);
  checkStable = checkRawPrev;
  checkChangeTick = HAL_GetTick();

  endRawPrev = HAL_GPIO_ReadPin(END_BTN_GPIO_Port, END_BTN_Pin);
  endStable = endRawPrev;
  endChangeTick = HAL_GetTick();

  modeRawPrev = HAL_GPIO_ReadPin(MODE_SW_GPIO_Port, MODE_SW_Pin);
  modeStable = modeRawPrev;
  modeChangeTick = HAL_GetTick();

  manualMode = 0;   // 부팅 시 기본 AUTO

  printf("MODE INIT -> AUTO\r\n");


  LCD_init(&hi2c3);

  LCD_writeStringXY(0, 0, "HMI READY");
  LCD_writeStringXY(1, 0, "MODE: AUTO");

  hmiState = HMI_READY;
  rgbBlinkTick = HAL_GetTick();
  rgbBlinkState = 0;
  RGB_Set(0, 0, 0);



  printf("start main() db\r\n");

  printf("ESTOP latch = %d\r\n", estopLatched);

  const char syncMsg[] = "[T8_CTRL]SYNC\n";

  HAL_UART_Transmit(&huart6,
                    (uint8_t *)syncMsg,
                    sizeof(syncMsg) - 1,
                    100);

  printf("HMI SYNC -> BT TX\r\n");


  /* MODE는 SYNC 응답으로 중앙제어 상태를 받아 동기화한다. */

//  if(HAL_ADC_Start_DMA(&hadc1, (uint32_t *)ADC1ConvertValue, 2) != HAL_OK){
//	  Error_Handler();
//  }
//  char buf[10] = "Hello\r";
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  while(btRxTail != btRxHead)
	  {
	      uint8_t tail = btRxTail;

	      strncpy(btData,
	              btRxQueue[tail],
	              CMD_SIZE - 1);

	      btData[CMD_SIZE - 1] = '\0';

	      btRxTail =
	          (uint8_t)((tail + 1U) % BT_RX_QUEUE_SIZE);

	      printf("bt : %s\r\n", btData);

	      bluetooth_Event();
	  }

      GPIO_PinState startRaw =
          HAL_GPIO_ReadPin(START_BTN_GPIO_Port, START_BTN_Pin);

      /* 실제 핀 상태가 변한 순간 기록 */
      if(startRaw != startRawPrev)
      {
          startRawPrev = startRaw;
          startChangeTick = HAL_GetTick();
      }

      /* 같은 상태가 30ms 이상 유지됐을 때만 진짜 상태 변화로 인정 */
      if((HAL_GetTick() - startChangeTick >= 30) &&
         (startRaw != startStable))
      {
          startStable = startRaw;

          /* Pull-up 방식이므로 LOW가 실제 버튼 누름 */
          if((startStable == GPIO_PIN_RESET) &&
             (estopLatched == 0))
          {
              if(manualMode)
              {
                  printf("START IGNORED : MANUAL MODE\r\n");
              }
              else
              {
                  const char startMsg[] = "[T8_CTRL]START\n";

                  HAL_UART_Transmit(&huart6,
                                    (uint8_t *)startMsg,
                                    sizeof(startMsg) - 1,
                                    100);

                  printf("START button -> BT TX\r\n");
              }
          }


      }
      GPIO_PinState checkRaw =
          HAL_GPIO_ReadPin(CHECK_BTN_GPIO_Port, CHECK_BTN_Pin);

      /* 실제 핀 상태가 바뀐 순간 기록 */
      if(checkRaw != checkRawPrev)
      {
          checkRawPrev = checkRaw;
          checkChangeTick = HAL_GetTick();
      }

      /* 같은 상태가 30ms 이상 유지되면 실제 변화로 인정 */
      if((HAL_GetTick() - checkChangeTick >= 30) &&
         (checkRaw != checkStable))
      {
          checkStable = checkRaw;

          /* Pull-up 방식이므로 LOW = 버튼 눌림 */
          if((checkStable == GPIO_PIN_RESET) &&
             (estopLatched == 0))
          {
              if(manualMode)
              {
                  printf("CHECK IGNORED : MANUAL MODE\r\n");
              }
              else
              {
                  const char checkMsg[] = "[T8_CTRL]CHECK\n";

                  HAL_UART_Transmit(&huart6,
                                    (uint8_t *)checkMsg,
                                    sizeof(checkMsg) - 1,
                                    100);

                  printf("CHECK button -> BT TX\r\n");
              }
          }
      }

      GPIO_PinState endRaw =
          HAL_GPIO_ReadPin(END_BTN_GPIO_Port, END_BTN_Pin);

      /* 실제 핀 상태가 바뀐 순간 기록 */
      if(endRaw != endRawPrev)
      {
          endRawPrev = endRaw;
          endChangeTick = HAL_GetTick();
      }

      /* 30ms 이상 같은 상태면 실제 변화로 인정 */
      if((HAL_GetTick() - endChangeTick >= 30) &&
         (endRaw != endStable))
      {
          endStable = endRaw;

          /* 버튼 눌림 */
          if(endStable == GPIO_PIN_RESET)
          {
              if(estopLatched == 0)
              {
                  /* 평상시 END는 기존 기능 유지 */
                  const char endMsg[] = "[T8_CTRL]END\n";

                  HAL_UART_Transmit(&huart6,
                                    (uint8_t *)endMsg,
                                    sizeof(endMsg) - 1,
                                    100);

                  printf("END button -> BT TX\r\n");


              }
              else
              {
                  /*
                   * E-STOP 상태에서는 END를 즉시 보내지 않고
                   * 2초 길게 누르기 측정 시작
                   */
                  endPressTick = HAL_GetTick();
                  estopClearSent = 0;

                  printf("ESTOP CLEAR : HOLD END 2 SEC\r\n");

                  LCD_writeStringXY(0, 0, "EMERGENCY STOP  ");
                  LCD_writeStringXY(1, 0, "HOLD END 2 SEC  ");
              }
          }

          /* 버튼 뗌 */
          else
          {
              endPressTick = 0;
              estopClearSent = 0;
          }
      }


      /* E-STOP 상태에서 END를 2초 계속 누르면 해제 요청 */
      if((estopLatched == 1) &&
         (endStable == GPIO_PIN_RESET) &&
         (estopClearSent == 0) &&
         (HAL_GetTick() - endPressTick >= ESTOP_CLEAR_HOLD_MS))
      {
          const char clearMsg[] = "[T8_CTRL]ESTOP_CLEAR\n";

          HAL_UART_Transmit(&huart6,
                            (uint8_t *)clearMsg,
                            sizeof(clearMsg) - 1,
                            100);

          estopClearSent = 1;

          printf("ESTOP_CLEAR -> BT TX\r\n");

          LCD_writeStringXY(0, 0, "CLEAR REQUEST   ");
          LCD_writeStringXY(1, 0, "WAIT CTRL ACK   ");
      }



		if(estopEvent)
		{
			estopEvent = 0;

			endPressTick = 0;
			estopClearSent = 0;

			const char estopMsg[] = "[T8_CTRL]ESTOP\n";

			HAL_UART_Transmit(&huart6,
							  (uint8_t *)estopMsg,
							  sizeof(estopMsg) - 1,
							  100);

			printf("!!! E-STOP LATCHED !!!\r\n");

		    LCD_writeStringXY(0, 0, "EMERGENCY STOP  ");
		    LCD_writeStringXY(1, 0, "SYSTEM LOCKED   ");
		    hmiState = HMI_ESTOP;
		    rgbBlinkTick = HAL_GetTick();
		    rgbBlinkState = 0;
		}


		GPIO_PinState modeRaw =
		    HAL_GPIO_ReadPin(MODE_SW_GPIO_Port, MODE_SW_Pin);

		/* 실제 핀 상태가 바뀐 순간 기록 */
		if(modeRaw != modeRawPrev)
		{
		    modeRawPrev = modeRaw;
		    modeChangeTick = HAL_GetTick();
		}

		/* 같은 상태가 30ms 이상 유지되면 실제 변화로 인정 */
		if((HAL_GetTick() - modeChangeTick >= 30) &&
		   (modeRaw != modeStable))
		{
		    modeStable = modeRaw;

		    /* Pull-up 방식이므로 LOW = 버튼 눌림 */
		    if((modeStable == GPIO_PIN_RESET) &&
		       (estopLatched == 0))
		    {
		        const char *modeMsg;

		        /* 중앙제어가 MODE의 최종 권한을 가진다. */
		        modeMsg = manualMode ?
		                  "[T8_CTRL]MODE@AUTO\n" :
		                  "[T8_CTRL]MODE@MANUAL\n";

		        HAL_UART_Transmit(&huart6,
		                          (uint8_t *)modeMsg,
		                          strlen(modeMsg),
		                          100);

		        printf("MODE CHANGE REQUEST -> BT TX\r\n");
		    }
		    }


		if((manualMode == 1) &&
		   (estopLatched == 0) &&
		   (HAL_GetTick() - potReadTick >= 200))
		{
		    potReadTick = HAL_GetTick();

		    HAL_ADC_Start(&hadc1);

		    if(HAL_ADC_PollForConversion(&hadc1, 10) == HAL_OK)
		    {
		        potValue = HAL_ADC_GetValue(&hadc1);

		        /* MANUAL 진입 후 첫 ADC 값은 즉시 기준값으로 설정 */
		        if(potInitialized == 0)
		        {
		            potAccepted = potValue;
		            potInitialized = 1;

		            trayAngle = (potAccepted * 180UL) / 4095UL;

		            printf("POT = %u, TRAY ANGLE = %u\r\n",
		                   potAccepted,
		                   trayAngle);
		        }
		        else
		        {
		            uint16_t potDiff;

		            if(potValue > potAccepted)
		                potDiff = potValue - potAccepted;
		            else
		                potDiff = potAccepted - potValue;

		            /* Deadband 이상 움직였을 때만 새로운 값 인정 */
		            if(potDiff >= POT_DEADBAND)
		            {
		                char trayMsg[40];

		                potAccepted = potValue;

		                trayAngle = (potAccepted * 180UL) / 4095UL;

		                printf("POT = %u, TRAY ANGLE = %u\r\n",
		                       potAccepted,
		                       trayAngle);

		                snprintf(trayMsg,
		                         sizeof(trayMsg),
		                         "[T8_CTRL]TRAY@%u\n",
		                         trayAngle);

		                HAL_UART_Transmit(&huart6,
		                                  (uint8_t *)trayMsg,
		                                  strlen(trayMsg),
		                                  100);
		            }
		        }
		    }

		    HAL_ADC_Stop(&hadc1);
		}
		RGB_Update();
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }


  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief I2C3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C3_Init(void)
{

  /* USER CODE BEGIN I2C3_Init 0 */

  /* USER CODE END I2C3_Init 0 */

  /* USER CODE BEGIN I2C3_Init 1 */

  /* USER CODE END I2C3_Init 1 */
  hi2c3.Instance = I2C3;
  hi2c3.Init.ClockSpeed = 100000;
  hi2c3.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c3.Init.OwnAddress1 = 0;
  hi2c3.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c3.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c3.Init.OwnAddress2 = 0;
  hi2c3.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c3.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C3_Init 2 */

  /* USER CODE END I2C3_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART6_UART_Init(void)
{

  /* USER CODE BEGIN USART6_Init 0 */

  /* USER CODE END USART6_Init 0 */

  /* USER CODE BEGIN USART6_Init 1 */

  /* USER CODE END USART6_Init 1 */
  huart6.Instance = USART6;
  huart6.Init.BaudRate = 9600;
  huart6.Init.WordLength = UART_WORDLENGTH_8B;
  huart6.Init.StopBits = UART_STOPBITS_1;
  huart6.Init.Parity = UART_PARITY_NONE;
  huart6.Init.Mode = UART_MODE_TX_RX;
  huart6.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart6.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart6) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART6_Init 2 */

  /* USER CODE END USART6_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */
  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LD3_Pin|LD2_Pin|RGB_R_Pin|RGB_G_Pin
                          |DHT11_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(RGB_B_GPIO_Port, RGB_B_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : MODE_SW_Pin END_BTN_Pin */
  GPIO_InitStruct.Pin = MODE_SW_Pin|END_BTN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : LD3_Pin LD2_Pin RGB_R_Pin RGB_G_Pin
                           DHT11_Pin */
  GPIO_InitStruct.Pin = LD3_Pin|LD2_Pin|RGB_R_Pin|RGB_G_Pin
                          |DHT11_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : RGB_B_Pin */
  GPIO_InitStruct.Pin = RGB_B_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(RGB_B_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : ESTOP_BTN_Pin */
  GPIO_InitStruct.Pin = ESTOP_BTN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(ESTOP_BTN_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : CHECK_BTN_Pin START_BTN_Pin */
  GPIO_InitStruct.Pin = CHECK_BTN_Pin|START_BTN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void RGB_Set(uint8_t r, uint8_t g, uint8_t b)
{
    HAL_GPIO_WritePin(RGB_R_GPIO_Port, RGB_R_Pin,
                      r ? GPIO_PIN_SET : GPIO_PIN_RESET);

    HAL_GPIO_WritePin(RGB_G_GPIO_Port, RGB_G_Pin,
                      g ? GPIO_PIN_SET : GPIO_PIN_RESET);

    HAL_GPIO_WritePin(RGB_B_GPIO_Port, RGB_B_Pin,
                      b ? GPIO_PIN_SET : GPIO_PIN_RESET);
}
void HMI_ShowMode(void)
{
    if(manualMode)
    {
        LCD_writeStringXY(1, 0, "MODE: MANUAL    ");
    }
    else
    {
        LCD_writeStringXY(1, 0, "MODE: AUTO      ");
    }
}

void RGB_Update(void)
{
    switch(hmiState)
    {
        case HMI_READY:
            if(HAL_GetTick() - rgbBlinkTick >= 500)
            {
                rgbBlinkTick = HAL_GetTick();
                rgbBlinkState = !rgbBlinkState;
                RGB_Set(0, rgbBlinkState, 0);
            }
            break;

        case HMI_WORKING:
        case HMI_PASS:
            RGB_Set(0, 1, 0);
            break;

        case HMI_INSPECTING:
            if(HAL_GetTick() - rgbBlinkTick >= 500)
            {
                rgbBlinkTick = HAL_GetTick();
                rgbBlinkState = !rgbBlinkState;
                RGB_Set(rgbBlinkState, rgbBlinkState, rgbBlinkState);
            }
            break;

        case HMI_FAIL:
            RGB_Set(1, 1, 0);
            break;

        case HMI_HOMING:
            RGB_Set(1, 1, 1);
            break;

        case HMI_ESTOP:
            if(HAL_GetTick() - rgbBlinkTick >= 250)
            {
                rgbBlinkTick = HAL_GetTick();
                rgbBlinkState = !rgbBlinkState;
                RGB_Set(rgbBlinkState, 0, 0);
            }
            break;

        default:
            RGB_Set(0, 0, 0);
            break;
    }
}

void MX_GPIO_LED_ON(int pin)
{
	HAL_GPIO_WritePin(LD2_GPIO_Port, pin, GPIO_PIN_SET);
}
void MX_GPIO_LED_OFF(int pin)
{
	HAL_GPIO_WritePin(LD2_GPIO_Port, pin, GPIO_PIN_RESET);
}
void bluetooth_Event()
{
    int i = 0;
    char *pToken;
    char *pArray[ARR_CNT] = {0};

    char recvBuf[CMD_SIZE] = {0};
    char sendBuf[CMD_SIZE] = {0};

    strncpy(recvBuf, btData, sizeof(recvBuf) - 1);
    recvBuf[sizeof(recvBuf) - 1] = '\0';

    printf("btData : %s\r\n", btData);

  pToken = strtok(recvBuf,"[@]");
  while(pToken != NULL)
  {
    pArray[i] =  pToken;
    if(++i >= ARR_CNT)
      break;
    pToken = strtok(NULL,"[@]");
  }
//  printf("pArray[0] : %s\r\n",pArray[0]);
//  printf("pArray[1] : %s\r\n",pArray[1]);
//  printf("pArray[2] : %s\r\n",pArray[2]);
  /* 잘못된 패킷 방어 */

  if((i >= 2) &&
     !strcmp(pArray[0], "T8_CTRL") &&
     !strcmp(pArray[1], "ESTOP_CLEARED"))
  {
      estopLatched = 0;
      estopEvent = 0;

      endPressTick = 0;
      estopClearSent = 0;

      /* MODE는 E-STOP 전 값을 유지 */
      potInitialized = 0;

      hmiState = HMI_READY;

      rgbBlinkTick = HAL_GetTick();
      rgbBlinkState = 0;

      LCD_writeStringXY(0, 0, "HMI READY       ");
      HMI_ShowMode();

      printf("ESTOP CLEARED BY CTRL\r\n");

      return;
  }

  if((pArray[1] == NULL) || (pArray[2] == NULL))
  {
      printf("BT packet error\r\n");
      return;
  }

  if(!strcmp(pArray[0], "T8_CTRL") && !strcmp(pArray[1], "MODE"))
  {
      if(!strcmp(pArray[2], "AUTO"))
      {
          manualMode = 0;
          potInitialized = 0;
          HMI_ShowMode();
          printf("MODE ACK -> AUTO\r\n");
          return;
      }

      if(!strcmp(pArray[2], "MANUAL"))
      {
          manualMode = 1;
          potInitialized = 0;
          HMI_ShowMode();
          printf("MODE ACK -> MANUAL\r\n");
          return;
      }

      printf("UNKNOWN MODE : %s\r\n", pArray[2]);
      return;
  }

  /* 프로젝트용 상태 명령 */
  if(strcmp(pArray[1], "STATE") == 0)
  {

	  /* 중앙제어가 현재 ESTOP 상태라고 알려온 경우 */
	  if(strcmp(pArray[2], "ESTOP") == 0)
	  {
	      estopLatched = 1;
	      estopEvent = 0;

	      /* MODE는 유지하고 ADC 기준값만 재설정 */
	      potInitialized = 0;

	      hmiState = HMI_ESTOP;

	      rgbBlinkTick = HAL_GetTick();
	      rgbBlinkState = 0;

	      LCD_writeStringXY(0, 0, "EMERGENCY STOP  ");
	      LCD_writeStringXY(1, 0, "SYSTEM LOCKED   ");

	      printf("STATE -> ESTOP\r\n");

	      return;
	  }

      /* E-STOP latch 중에는 일반 상태 명령 전부 무시 */
      if(estopLatched)
      {
          printf("STATE %s ignored : ESTOP latched\r\n",
                 pArray[2]);
          return;
      }

      /* READY */
      if(strcmp(pArray[2], "READY") == 0)
      {
          hmiState = HMI_READY;

          LCD_writeStringXY(0, 0, "HMI READY       ");
          HMI_ShowMode();

          rgbBlinkTick = HAL_GetTick();
          rgbBlinkState = 0;

          printf("STATE -> READY\r\n");
          return;
      }

      /* WORKING */
      else if(strcmp(pArray[2], "WORKING") == 0)
      {
          hmiState = HMI_WORKING;

          LCD_writeStringXY(0, 0, "WORKING         ");

          printf("STATE -> WORKING\r\n");
          return;
      }

      /* INSPECTING */
      else if(strcmp(pArray[2], "INSPECTING") == 0)
      {
          hmiState = HMI_INSPECTING;

          LCD_writeStringXY(0, 0, "INSPECTING      ");

          rgbBlinkTick = HAL_GetTick();
          rgbBlinkState = 0;

          printf("STATE -> INSPECTING\r\n");
          return;
      }

      /* PASS */
      else if(strcmp(pArray[2], "PASS") == 0)
      {
          hmiState = HMI_PASS;

          LCD_writeStringXY(0, 0, "INSPECT PASS    ");

          printf("STATE -> PASS\r\n");
          return;
      }

      /* FAIL / REWORK */
      else if(strcmp(pArray[2], "FAIL") == 0)
      {
          hmiState = HMI_FAIL;

          LCD_writeStringXY(0, 0, "INSPECT FAIL    ");

          printf("STATE -> FAIL\r\n");
          return;
      }

      /* HOME 복귀 시퀀스 */
      else if(strcmp(pArray[2], "HOMING") == 0)
      {
          hmiState = HMI_HOMING;

          LCD_writeStringXY(0, 0, "RETURN HOME     ");

          printf("STATE -> HOMING\r\n");
          return;
      }

      /* 정의되지 않은 STATE 명령 */
      else
      {
          printf("UNKNOWN STATE : %s\r\n", pArray[2]);
          return;
      }
  }
  if(!strcmp(pArray[1],"PLUG"))
  {
		if(!strcmp(pArray[2],"ON"))
		{
			MX_GPIO_LED_ON(LD2_Pin);
		}
		else if(!strcmp(pArray[2],"OFF"))
		{
			MX_GPIO_LED_OFF(LD2_Pin);
		}
		sprintf(sendBuf, "[T8_DB]SETDB@%s@%s@%s\n",pArray[1],pArray[2],pArray[0]);
  }
  else if(!strcmp(pArray[1],"LAMP"))
  {
		if(!strcmp(pArray[2],"ON"))
		{
			MX_GPIO_LED_ON(LD3_Pin);
		}
		else if(!strcmp(pArray[2],"OFF"))
		{
			MX_GPIO_LED_OFF(LD3_Pin);
		}
		sprintf(sendBuf, "[T8_DB]SETDB@%s@%s@%s\n",pArray[1],pArray[2],pArray[0]);
  }
  else if(!strncmp(pArray[1]," New conn",sizeof(" New conn")))
  {
      return;
  }
  else if(!strncmp(pArray[1]," Already log",sizeof(" Already log")))
  {
      return;
  }
  else
      return;

//  sprintf(sendBuf,"[%s]%s@%s\n",pArray[0],pArray[1],pArray[2]);
  HAL_UART_Transmit(&huart6, (uint8_t *)sendBuf, strlen(sendBuf), 0xFFFF);

}
/**
  * @brief  Retargets the C library printf function to the USART.
  * @param  None
  * @retval None
  */
PUTCHAR_PROTOTYPE
{
  /* Place your implementation of fputc here */
  /* e.g. write a character to the USART6 and Loop until the end of transmission */
  HAL_UART_Transmit(&huart2, (uint8_t *)&ch, 1, 0xFFFF);

  return ch;
}
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if(huart->Instance == USART2)
    {
    	static int i=0;
    	rx2Data[i] = rx2char;
    	if((rx2Data[i] == '\r') ||
    	   (rx2Data[i] == '\n'))
    	{
    		rx2Data[i] = '\0';
    		rx2Flag = 1;
    		i = 0;
    	}
    	else
    	{
    		i++;
    	}
    	HAL_UART_Receive_IT(&huart2, &rx2char,1);
    }
    if(huart->Instance == USART6)
    {
        static uint16_t i = 0;

        if((btchar == '\n') || (btchar == '\r'))
        {
            if(i > 0)
            {
                uint8_t head = btRxHead;

                btRxQueue[head][i] = '\0';

                uint8_t nextHead =
                    (uint8_t)((head + 1U) % BT_RX_QUEUE_SIZE);

                if(nextHead != btRxTail)
                {
                    btRxHead = nextHead;
                }
                else
                {
                    /*
                     * Queue가 가득 찬 경우
                     * ISR에서는 출력하지 않고 drop 횟수만 기록
                     */
                    btRxDropCount++;
                }

                i = 0;
            }
        }
        else
        {
            if(i < CMD_SIZE - 1)
            {
                btRxQueue[btRxHead][i++] = btchar;
            }
            else
            {
                /*
                 * 한 패킷이 비정상적으로 길면
                 * 현재 작성 중인 패킷만 폐기
                 */
                i = 0;
                btRxQueue[btRxHead][0] = '\0';
                btRxDropCount++;
            }
        }

        HAL_UART_Receive_IT(&huart6,
                            &btchar,
                            1);
    }
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc){
#if 0
	static int channel = 0;
	if(channel == 0){
		ADC1ConcertValue[channel] = HAL_ADC_GetValue(hadc);
		channel = 1;
	}
	else if(channel == 1){
		ADC1ConcertValue[channel] = HAL_ADC_GetValue(hadc);
		channel = 0;
		adcFlag = 1;
	}
#endif

	adcFlag = 1;
}


void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if(GPIO_Pin == ESTOP_BTN_Pin)
    {
        if(estopLatched == 0)
        {
            estopLatched = 1;
            estopEvent = 1;
        }
    }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
