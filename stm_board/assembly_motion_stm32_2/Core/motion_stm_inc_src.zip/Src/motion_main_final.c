/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "esp.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define ARR_CNT             4
#define SERVO_FAIL_ANGLE    30
#define SERVO_HOME_ANGLE    90
#define SERVO_PASS_ANGLE    150
#define SORT_HOLD_MS        1000U
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;

UART_HandleTypeDef huart2;
UART_HandleTypeDef huart6;

/* USER CODE BEGIN PV */
uint8_t sortActive = 0;
uint32_t sortStartTick = 0;

#define SORT_RESULT_NONE   0
#define SORT_RESULT_PASS   1
#define SORT_RESULT_FAIL   2

uint8_t sortResult = SORT_RESULT_NONE;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART6_UART_Init(void);
static void MX_TIM3_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM4_Init(void);
/* USER CODE BEGIN PFP */
char strBuff[MAX_ESP_MESSAGE_LEN];
void esp_event(char *recvBuf);
static int parse_int_range(const char *text, int min_value, int max_value, int *out);
void Servo_SetAngle(uint16_t angle);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
  int ret = 0;
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_USART6_UART_Init();
  MX_TIM4_Init();
  /* USER CODE BEGIN 2 */
if(HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1) != HAL_OK)
  {
      Error_Handler();
  }

  Servo_SetAngle(SERVO_HOME_ANGLE);
  printf("STM32 #2 MOTION BOOT\r\n");

  /* ESP-01 UART 수신 시작 + AT 응답 확인 */
  ret = drv_esp_init();

  if(ret == 0)
  {
      printf("ESP response OK\r\n");

      ret = AiotClient_Init();
      if(ret == 0)
      {    printf("T8_MOTION SERVER CONNECT OK\r\n");
      	  esp_send_data("[T8_MOTION:PASSWD]");
      }
      else
          printf("T8_MOTION SERVER CONNECT FAIL : %d\r\n", ret);
  }
  else
  {
      printf("ESP response FAIL : %d\r\n", ret);
  }
/* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
while (1)
  {
      int msgLen = esp_get_message(strBuff, sizeof(strBuff));

      if(msgLen > 0)
      {
          printf("ESP RX : %s\r\n", strBuff);
          esp_event(strBuff);
      }

      /* AUTO SORT : PASS/FAIL 위치를 1초 유지한 뒤 HOME으로 복귀 */
      if(sortActive &&
         (uint32_t)(HAL_GetTick() - sortStartTick) >= SORT_HOLD_MS)
      {
          char doneBuf[64];

          Servo_SetAngle(SERVO_HOME_ANGLE);
          sortActive = 0;

          if(sortResult == SORT_RESULT_PASS)
              snprintf(doneBuf, sizeof(doneBuf), "[T8_CTRL]SORT_DONE@PASS\n");
          else if(sortResult == SORT_RESULT_FAIL)
              snprintf(doneBuf, sizeof(doneBuf), "[T8_CTRL]SORT_DONE@FAIL\n");
          else
              doneBuf[0] = '\0';

          printf("SORT COMPLETE -> HOME %d\r\n", SERVO_HOME_ANGLE);

          if(doneBuf[0] != '\0')
          {
              if(esp_send_data(doneBuf) == 0)
                  printf("SORT DONE TX : %s\r\n",
                         sortResult == SORT_RESULT_PASS ? "PASS" : "FAIL");
              else
                  printf("SORT DONE TX FAIL\r\n");
          }

          sortResult = SORT_RESULT_NONE;
      }

      HAL_Delay(10);
  }
/* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

  /* USER CODE END 3 */

}
/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 84-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 1000-1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 84-1;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 20000-1;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 500;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */
  HAL_TIM_MspPostInit(&htim4);

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 38400;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART6_UART_Init(void)
{

  /* USER CODE BEGIN USART6_Init 0 */

  /* USER CODE END USART6_Init 0 */

  /* USER CODE BEGIN USART6_Init 1 */

  /* USER CODE END USART6_Init 1 */
  huart6.Instance = USART6;
  huart6.Init.BaudRate = 38400;
  huart6.Init.WordLength = UART_WORDLENGTH_8B;
  huart6.Init.StopBits = UART_STOPBITS_1;
  huart6.Init.Parity = UART_PARITY_NONE;
  huart6.Init.Mode = UART_MODE_TX_RX;
  huart6.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart6.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart6) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART6_Init 2 */

  /* USER CODE END USART6_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  /* Peripheral alternate-function pins are configured by HAL MSP code. */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
}

/* USER CODE BEGIN 4 */
void Servo_SetAngle(uint16_t angle)
{
    uint32_t pulse;

    if(angle > 180U)
        angle = 180U;

    /* SG90 실측 보정: 0°=650us, 90°=1575us, 180°=2500us */
    pulse = 650U + ((uint32_t)angle * 1850UL / 180UL);

    __HAL_TIM_SetCompare(&htim4,
                         TIM_CHANNEL_1,
                         pulse - 1U);

    printf("SERVO angle=%u, pulse=%lu us\r\n",
           angle,
           (unsigned long)pulse);
}

static int parse_int_range(const char *text, int min_value, int max_value, int *out)
{
    char *endptr;
    long value;

    if(text == NULL || out == NULL || *text == '\0')
        return 0;

    value = strtol(text, &endptr, 10);

    if(*endptr != '\0' || value < min_value || value > max_value)
        return 0;

    *out = (int)value;
    return 1;
}

void esp_event(char *recvBuf)
{
    int count = 0;
    char *token;
    char *parts[ARR_CNT] = {0};
    char sendBuf[MAX_ESP_COMMAND_LEN] = {0};
    size_t recvLen;

    if(recvBuf == NULL)
        return;

    recvLen = strlen(recvBuf);
    while(recvLen > 0U &&
          (recvBuf[recvLen - 1U] == '\n' || recvBuf[recvLen - 1U] == '\r'))
    {
        recvBuf[--recvLen] = '\0';
    }

    printf("Debug recv : %s\r\n", recvBuf);

    token = strtok(recvBuf, "[@]");
    while(token != NULL && count < ARR_CNT)
    {
        parts[count++] = token;
        token = strtok(NULL, "[@]");
    }

    if(count < 2 || parts[0] == NULL || parts[1] == NULL)
        return;

    /* Motion actuator는 중앙제어 명령만 수용 */
    if(strcmp(parts[0], "T8_CTRL") != 0)
        return;

    if(strcmp(parts[1], "TRAY") == 0)
    {
        int angle;

        if(count < 3 || !parse_int_range(parts[2], 0, 180, &angle))
        {
            printf("TRAY VALUE ERROR\r\n");
            return;
        }

        sortActive = 0;
        sortResult = SORT_RESULT_NONE;
        Servo_SetAngle((uint16_t)angle);

        snprintf(sendBuf, sizeof(sendBuf),
                 "[T8_CTRL]TRAY@%d\n", angle);
    }
    else if(strcmp(parts[1], "SORT") == 0)
    {
        if(count < 3 || parts[2] == NULL)
        {
            printf("SORT VALUE ERROR\r\n");
            return;
        }

        if(strcmp(parts[2], "PASS") == 0)
        {
            Servo_SetAngle(SERVO_PASS_ANGLE);
            sortStartTick = HAL_GetTick();
            sortActive = 1;
            sortResult = SORT_RESULT_PASS;

            printf("SORT PASS -> SERVO %d\r\n", SERVO_PASS_ANGLE);
            snprintf(sendBuf, sizeof(sendBuf), "[T8_CTRL]SORT@PASS\n");
        }
        else if(strcmp(parts[2], "FAIL") == 0)
        {
            Servo_SetAngle(SERVO_FAIL_ANGLE);
            sortStartTick = HAL_GetTick();
            sortActive = 1;
            sortResult = SORT_RESULT_FAIL;

            printf("SORT FAIL -> SERVO %d\r\n", SERVO_FAIL_ANGLE);
            snprintf(sendBuf, sizeof(sendBuf), "[T8_CTRL]SORT@FAIL\n");
        }
        else
        {
            printf("SORT VALUE ERROR\r\n");
            return;
        }
    }
    else if(strcmp(parts[1], "ESTOP") == 0)
    {
        /* E-STOP은 예약된 자동동작만 취소하고 현재 위치는 유지 */
        sortActive = 0;
        sortResult = SORT_RESULT_NONE;

        printf("ESTOP -> SORT CANCEL / HOLD CURRENT POSITION\r\n");
        snprintf(sendBuf, sizeof(sendBuf), "[T8_CTRL]ESTOP@CANCELLED\n");
    }
    else if(strcmp(parts[1], "HOME") == 0)
    {
        /* HOME@DONE은 센서 피드백이 아니라 HOME 명령 처리 ACK */
        sortActive = 0;
        sortResult = SORT_RESULT_NONE;
        Servo_SetAngle(SERVO_HOME_ANGLE);

        printf("HOME -> SERVO %d\r\n", SERVO_HOME_ANGLE);
        snprintf(sendBuf, sizeof(sendBuf), "[T8_CTRL]HOME@DONE\n");
    }
    else
    {
        printf("UNKNOWN CTRL COMMAND : %s\r\n", parts[1]);
        return;
    }

    if(esp_send_data(sendBuf) == 0)
        printf("Debug send : %s", sendBuf);
    else
        printf("Debug send fail (server offline)\r\n");
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
